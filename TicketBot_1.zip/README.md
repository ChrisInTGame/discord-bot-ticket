## Self-Hosting 
- You're Free To Host This Bot 
> Enjoy :)
~ Coder TN hazem#6101

#Copyright 
- I have seen many people copying videos and code now I am warning to all those who - make video without permission then you will claim copyright.
Giving Credit in description is not better way to avoid copyright you have to ask permission. 
Dont copy code also and dont make video for this code.
# ButtonTickets
A Discord Tickets Bot With Buttons Just Like Ticket Tool!

# How to Setup
- Go into Secrets if you are using Replit
- Create TOKEN and give the bot_token
- Create PREFIX and give the prefix you want for the Bot
- Run the Bot and you are good to Go!!

# Features
- Setup 
- Open 
- Close
- Add
- Remove
- Rename
- Close
- Reopen
- Per Server Prefix 
- Ping Command


